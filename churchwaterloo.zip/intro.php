<!-- Section: intro -->
<section id="intro" class="intro">

    <div class="slogan wow bounceInLeft" data-wow-delay="0.2s">
        <h4>WELCOME TO</h4>
        <h2><span class="text_color">First Presbyterian Church of Waterloo</span> </h2>
        <h4>WE ARE LOCATED BY THE FINGER LAKES</h4>
    </div>
</section>
<!-- /Section: intro -->