<?php
// ** MySQL connection settings ** //
// // database host
define('DB_HOST', 'localhost');
// database name
define('DB_NAME', 'churchwaterloo');
// Your MySQL / Course Server username
define('DB_USER', 'churchwaterloo');
// ...and password
define('DB_PASSWORD', 'churchwaterloo123');
?>