<?php require 'head.php'; ?>
<?php require 'navigation.php'; ?>

<section class="home-section text-center">
    <div class="heading-about">
        <div class="container">
            <form action="uploadPhotos.php" method="post" enctype="multipart/form-data">
                <input type="file" name="newphoto"/>
                <label for="inputsm">Caption</label>
                <input class="form-control input-sm" type="text" name="note" placeholder="Caption for this photo"/>
                <select name="album">
                    <?php
                    $albums = $mysqli->query("select * from albums");
                    while ($album = $albums->fetch_assoc()) {
                        ?>
                        <option value=<?php echo $album['albumID'] ?>><?php echo $album['date'] ?></option>
                        <?php
                    }
                    ?>
                </select>
                <input type="submit" name="upload"/>
            </form>

<?php


if (isset($_POST['upload'])) {

    //check if a file has been selected
    if (!empty($_FILES['newphoto'])) {

        $newPhoto = $_FILES['newphoto'];

        //sanitize originalName for URL
        $originalName = $newPhoto['name'];
        $originalName = filter_var($originalName, FILTER_SANITIZE_STRING);


        //check that there are no errors
        if ($newPhoto['error'] == 0) {
            //upload selected file
            $tempName = $newPhoto['tmp_name'];
            move_uploaded_file($tempName, "img/albums/$originalName");
            $url = "img/albums/$originalName";
            $aID = $_POST['album'];
            $note = $_POST['note'];
            $mysqli->query("INSERT INTO photos VALUES (DEFAULT, '$note', '$url')");

            $test = $mysqli->query("select * from photos");
            $tempId = 0;
            while ($t = $test->fetch_assoc()) {
                $tempId = $t ["photoID"];
            }

            $mysqli->query("INSERT INTO contains VALUES (DEFAULT, '$aID', '$tempId' )");


            print("Photo successfully uploaded.\n");
        }
    } //error
    else {
        print("Error: The file could not be uploaded.\n");
    }
}
?>
        </div>
    </div>
</section>