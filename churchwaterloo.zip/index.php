<body id="page-top" data-spy="scroll" data-target=".navbar-custom">

<?php include 'head.php'; ?>
<?php include 'navigation.php' ?>
<?php include 'intro.php'; ?>

</body>

</html>